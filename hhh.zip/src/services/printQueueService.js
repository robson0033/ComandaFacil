"use strict";

const { logger: appLogger } = require("../utils/logger");
const adminRealtimeService = require("./adminRealtimeService");

const crypto = require("crypto");
const { normalizePrinterLayoutConfig } = require("./printerLayoutConfig");
const {
  AGENT_STATUSES,
  PROTOCOL_VERSION,
  UUID_PATTERN,
  buildJobEnvelope,
  compareVersions,
  validateAgentStatus,
} = require("./printAgentProtocol");
const {
  isPrintProtocolV2EnabledFor,
} = require("../config/printProtocolRollout");
const os = require("os");
const {
  Configuracao,
  Mesa,
  Pedido,
  PrintAgent,
  PrintJob,
} = require("../models/painelModels");
const { registroModel } = require("../models/registroModel");
const {
  gerarTokenAcompanhamento,
  gerarTokenAcompanhamentoIdempotente,
} = require("./pedidoPublicoTokenService");
const {
  codigoFinal,
  gerarCodigoPublico,
} = require("./pedidoPublicCodeService");
const {
  createIdempotencyConflictError,
  hashPublicOrderPayload,
} = require("../utils/publicOrderIdempotency");
const {
  formatarNumeroPedido,
  reservarNumeroPedido,
} = require("./pedidoNumeroService");

const INSTANCE_ID = `${os.hostname()}:${process.pid}:${crypto.randomUUID()}`;
const MAX_ATTEMPTS = 5;
const LEASE_MS = 60_000;
const RETRY_DELAYS = [0, 5_000, 30_000, 120_000, 600_000];
// O reconciliador serve apenas para recuperar uma falha recente entre a criação
// do pedido e a criação dos jobs. Ele não deve ressuscitar impressões históricas.
const ORDER_PRINT_RECONCILIATION_WINDOW_MS = 15 * 60 * 1000;
const activeStores = new Set();
let transport = null;
let shuttingDown = false;

function setTransport(value) {
  transport = value;
}

function assertAcceptingWork() {
  if (!shuttingDown) return;
  const error = new Error("Serviço temporariamente indisponível.");
  error.code = "SHUTTING_DOWN";
  error.statusCode = 503;
  throw error;
}

function setShuttingDown(value) {
  shuttingDown = Boolean(value);
}

function text(value, max) {
  return String(value ?? "").trim().slice(0, max);
}

function number(value) {
  const parsed = Number(value);
  return Number.isFinite(parsed) && parsed >= 0 ? parsed : 0;
}

function isPixOnlineOrder(pedido = {}) {
  if (["pix", "pix_online"].includes(
    String(pedido.formaPagamento || "").toLowerCase(),
  )) {
    return true;
  }

  return Array.isArray(pedido.pagamentos)
    && pedido.pagamentos.some(item =>
      ["pix", "pix_online"].includes(
        String(item?.formaPagamento || "").toLowerCase(),
      )
      && Number(item?.valorCentavos || 0) > 0,
    );
}

function isOrderEligibleForAutomaticPrint(pedido = {}) {
  if (!pedido || pedido.status === "cancelado" || pedido.excluido === true) {
    return false;
  }
  if (isPixOnlineOrder(pedido)) {
    // No pagamento combinado, somente a parte Pix é confirmada online. O
    // restante continua pendente para recebimento na entrega/retirada, mas o
    // pedido já pode seguir para produção assim que o Pix for aprovado.
    if (String(pedido.formaPagamento || "") === "combinado") {
      return pedido.mercadoPagoStatus === "approved";
    }
    return pedido.pagamentoStatus === "pago"
      && pedido.mercadoPagoStatus === "approved";
  }
  return true;
}

function motivoImpressaoAutomatica(pedido = {}) {
  return isPixOnlineOrder(pedido) ? "payment_approved" : "order_created";
}

async function marcarImpressaoAutomaticaProcessada(pedido, { session = null } = {}) {
  if (!pedido?._id || !pedido?.estabelecimentoId) return;
  const motivo = motivoImpressaoAutomatica(pedido);
  const processadaEm = new Date();
  const options = session ? { session } : undefined;

  await Pedido.updateOne({
    _id: pedido._id,
    estabelecimentoId: pedido.estabelecimentoId,
  }, {
    $set: {
      impressaoAutomaticaProcessadaEm: processadaEm,
      impressaoAutomaticaMotivo: motivo,
    },
  }, options);

  // Mantém o documento em memória coerente para chamadas subsequentes no mesmo fluxo.
  pedido.impressaoAutomaticaProcessadaEm = processadaEm;
  pedido.impressaoAutomaticaMotivo = motivo;
}

function impressaoAutomaticaJaProcessada(pedido = {}) {
  if (!pedido.impressaoAutomaticaProcessadaEm) return false;
  return String(pedido.impressaoAutomaticaMotivo || "")
    === motivoImpressaoAutomatica(pedido);
}

function erroPedidoIndisponivel() {
  const error = new Error("Pedido indisponível para impressão.");
  error.code = "PEDIDO_INDISPONIVEL";
  error.statusCode = 409;
  return error;
}

async function validarPedidoDisponivel(pedido, { session = null } = {}) {
  if (!pedido?._id || !pedido?.estabelecimentoId) {
    throw erroPedidoIndisponivel();
  }
  const existente = await Pedido.findOne(
    {
      _id: pedido._id,
      estabelecimentoId: pedido.estabelecimentoId,
      excluido: { $ne: true },
    },
    null,
    session ? { session } : {},
  ).select("_id estabelecimentoId");
  if (!existente) throw erroPedidoIndisponivel();
  return existente;
}

function calcularImpressoraId(impressora = {}) {
  return impressora.tipoConexao === "rede"
    ? `rede:${text(impressora.ip, 15)}:${Number(impressora.porta || 9100)}`
    : `usb:${text(impressora.deviceName, 200).toLowerCase()}`;
}

function calcularImpressoraChave(impressora = {}) {
  // Mantém a chave hash apenas para idempotência/índice no MongoDB.
  // O protocolo do agente NÃO aceita essa hash: ele exige o identificador
  // canônico usb:<deviceName> ou rede:<ip>:<porta>.
  return crypto.createHash("sha256")
    .update(calcularImpressoraId(impressora))
    .digest("hex");
}

function normalizarOrigemPedidosImpressora(valor) {
  const origem = String(valor || "todas").trim().toLowerCase();
  return [
    "delivery",
    "mesa",
    "retirada",
    "delivery_retirada",
  ].includes(origem)
    ? origem
    : "todas";
}

function normalizarCanalPedidoParaImpressao(valor) {
  const canal = String(valor || "retirada").trim().toLowerCase();
  // "balcao" é o valor legado usado por pedidos antigos de retirada no local.
  return canal === "balcao" ? "retirada" : canal;
}

function impressoraAceitaPedido(impressora = {}, pedido = {}) {
  const origemConfigurada = normalizarOrigemPedidosImpressora(
    impressora.origemPedidos,
  );
  if (origemConfigurada === "todas") return true;

  const canalPedido = normalizarCanalPedidoParaImpressao(pedido.canal);
  if (origemConfigurada === "delivery_retirada") {
    return ["delivery", "retirada"].includes(canalPedido);
  }
  return canalPedido === origemConfigurada;
}


function modosAceitosParaTipoJob(tipo) {
  return String(tipo) === "manual"
    ? ["manual", "manual_automatica"]
    : ["automatica", "manual_automatica"];
}

function impressoraPodeAtenderJob(impressora = {}, job = {}) {
  return modosAceitosParaTipoJob(job.tipo).includes(String(impressora.modo || ""))
    && calcularImpressoraChave(impressora) === String(job.impressoraChave || "")
    && impressoraAceitaPedido(impressora, job.pedido || {});
}

async function reconciliarJobsComImpressorasAtuais(
  estabelecimentoId,
  impressorasFornecidas = null,
) {
  if (shuttingDown || !estabelecimentoId) return { verificados: 0, cancelados: 0 };

  let impressoras = impressorasFornecidas;
  if (!Array.isArray(impressoras)) {
    const configuracao = await Configuracao.findOne({ estabelecimentoId })
      .select("impressoras")
      .lean();
    // Não cancela nada se a configuração não pôde ser encontrada.
    if (!configuracao) return { verificados: 0, cancelados: 0 };
    impressoras = configuracao.impressoras || [];
  }

  const jobs = await PrintJob.find({
    estabelecimentoId,
    status: { $in: ["pendente", "aguardando_retry"] },
  })
    .select("_id tipo impressoraChave pedido status")
    .limit(500)
    .lean();

  const orfaos = jobs.filter(job =>
    !impressoras.some(impressora => impressoraPodeAtenderJob(impressora, job)));
  if (!orfaos.length) return { verificados: jobs.length, cancelados: 0 };

  const ids = orfaos.map(job => job._id);
  const result = await PrintJob.updateMany({
    _id: { $in: ids },
    estabelecimentoId,
    status: { $in: ["pendente", "aguardando_retry"] },
  }, {
    $set: {
      status: "cancelado",
      erro: "Impressora removida, desativada ou não configurada para esta origem. Reimprima manualmente se necessário.",
      lockedBy: "",
      leaseToken: "",
      leaseExpiresAt: null,
    },
  });

  const cancelados = Number(result?.modifiedCount || 0);
  if (cancelados > 0) {
    appLogger.warn("print_queue_orphan_jobs_cancelled", {
      estabelecimentoIdSuffix: String(estabelecimentoId).slice(-8),
      cancelados,
    });
  }
  return {
    verificados: jobs.length,
    cancelados,
  };
}

async function reconciliarJobsOrfaos({ limit = 500 } = {}) {
  if (shuttingDown) return { verificados: 0, cancelados: 0, lojas: 0 };

  const idsLojas = await PrintJob.distinct("estabelecimentoId", {
    status: { $in: ["pendente", "aguardando_retry"] },
  });
  const limiteLojas = Math.max(1, Math.min(2000, Number(limit) || 500));
  const lojas = [...new Set(idsLojas
    .map(id => String(id || ""))
    .filter(Boolean))].slice(0, limiteLojas);
  let verificados = 0;
  let cancelados = 0;

  for (const lojaId of lojas) {
    const result = await reconciliarJobsComImpressorasAtuais(lojaId);
    verificados += result.verificados;
    cancelados += result.cancelados;
  }

  return { verificados, cancelados, lojas: lojas.length };
}

async function finalizarJobsEsgotados({ now = new Date() } = {}) {
  if (shuttingDown) return { modifiedCount: 0 };
  const result = await PrintJob.updateMany({
    status: { $in: ["pendente", "aguardando_retry"] },
    tentativas: { $gte: MAX_ATTEMPTS },
    $and: [
      {
        $or: [
          { nextAttemptAt: null },
          { nextAttemptAt: { $lte: now } },
        ],
      },
      {
        $or: [
          { leaseExpiresAt: null },
          { leaseExpiresAt: { $lt: now } },
        ],
      },
    ],
  }, {
    $set: {
      status: "falhou",
      erro: "Limite de tentativas de impressão atingido. Use Reimprimir para tentar novamente.",
      lockedBy: "",
      leaseToken: "",
      leaseExpiresAt: null,
    },
  });
  const finalizados = Number(result?.modifiedCount || 0);
  if (finalizados > 0) {
    appLogger.warn("print_queue_exhausted_jobs_failed", { finalizados });
  }
  return result;
}

// Campos usados somente pelo servidor para identificar/deduplicar uma comanda
// consolidada. O agente v1.3.0 valida o payload com allowlist estrita e rejeita
// qualquer campo desconhecido. Eles permanecem persistidos no PrintJob, mas
// nunca atravessam o protocolo v2 enviado ao computador da loja.
const CAMPOS_PEDIDO_SOMENTE_SERVIDOR = new Set([
  "codigoPublico",
  "documentoTipo",
  "comandaMesaId",
  "comandaChave",
  "comandaQuantidadePedidos",
  "comandaPedidoIds",
]);

function sanitizarPedidoParaAgente(pedido = {}) {
  if (!pedido || typeof pedido !== "object" || Array.isArray(pedido)) return pedido;
  return Object.fromEntries(
    Object.entries(pedido).filter(([chave]) => !CAMPOS_PEDIDO_SOMENTE_SERVIDOR.has(chave)),
  );
}

function sanitizarImpressora(impressora = {}) {
  const allowed = [
    "nome", "tipoConexao", "deviceName", "ip", "porta", "papel", "modo",
    "copias", "fontePx", "espacamentoLinhaPx", "espacamentoLetrasPx",
    "margemSuperiorMm", "margemInferiorMm", "margemEsquerdaMm",
    "margemDireitaMm", "alturaMaximaMm", "imprimirLogo", "imprimirValores",
    "imprimirEndereco", "imprimirCpfCnpj", "imprimirObservacoes",
    "corteAutomatico",
  ];
  const sanitized = Object.fromEntries(allowed
    .filter(key => impressora[key] !== undefined)
    .map(key => [key, impressora[key]]));
  return normalizePrinterLayoutConfig(sanitized);
}

async function montarSnapshotValidado({
  pedido,
  configuracao,
  dono,
  impressora,
}) {
  let mesaNumero = pedido.mesaId?.numero || null;
  if (!mesaNumero && pedido.mesaId) {
    const mesa = await Mesa.findById(pedido.mesaId).select("numero").lean();
    mesaNumero = mesa?.numero || null;
  }
  const origem = pedido.canal === "delivery"
    ? "Delivery"
    : pedido.canal === "mesa"
      ? `Mesa ${mesaNumero || ""}`.trim()
      : "Retirada";
  return {
    impressora: sanitizarImpressora(impressora),
    estabelecimento: {
      nome: text(configuracao?.nomeEstabelecimento || "ComandaFacil", 160),
      telefone: text(configuracao?.telefone, 40),
      endereco: text(configuracao?.endereco, 300),
      cpfCnpj: text(dono?.cpfCnpj, 30),
      logoUrl: text(configuracao?.fotoPerfil, 2_000),
    },
    pedido: {
      id: String(pedido._id),
      numero: text(formatarNumeroPedido(pedido.numeroPedido) || pedido.codigoPublico, 12),
      codigoPublico: text(pedido.codigoPublico, 8),
      documentoTipo: text(pedido.documentoTipo, 40),
      comandaMesaId: text(pedido.comandaMesaId, 80),
      comandaChave: text(pedido.comandaChave, 128),
      comandaQuantidadePedidos: Math.max(0, Math.trunc(number(pedido.comandaQuantidadePedidos))),
      comandaPedidoIds: Array.isArray(pedido.comandaPedidoIds)
        ? pedido.comandaPedidoIds.slice(0, 100).map(id => text(id, 80)).filter(Boolean)
        : [],
      origem,
      canal: text(pedido.canal || "retirada", 30),
      mesaNumero,
      cliente: text(pedido.cliente || "Cliente não informado", 160),
      telefone: text(pedido.telefoneCliente, 40),
      // O agente valida os nomes canônicos do protocolo de impressão,
      // enquanto o Pedido persiste os campos com o sufixo "Entrega".
      // Manter o endereço legado preserva compatibilidade com pedidos antigos;
      // os campos estruturados garantem Rua, Número, Bairro e Referência.
      endereco: text(pedido.enderecoEntrega, 500),
      rua: text(pedido.ruaEntrega, 220),
      numeroEndereco: text(pedido.numeroEntrega, 40),
      bairro: text(pedido.bairroEntrega, 160),
      referencia: text(pedido.referenciaEntrega, 300),
      cidadeEntrega: text(pedido.cidadeEntregaNome, 120),
      cidadeEntregaUf: text(pedido.cidadeEntregaUf, 2),
      observacao: text(pedido.observacao, 1_000),
      subtotalProdutos: number(
        pedido.subtotalProdutos
        || Math.max(0, number(pedido.total) - number(pedido.taxaEntregaCentavos) / 100),
      ),
      taxaEntregaCentavos: Math.max(0, Math.trunc(number(pedido.taxaEntregaCentavos))),
      taxaEntrega: number(pedido.taxaEntregaCentavos) / 100,
      total: number(pedido.total),
      status: text(pedido.status || "novo", 30),
      pagamentoStatus: text(pedido.pagamentoStatus || "pendente", 30),
      formaPagamento: text(pedido.formaPagamento || "nao_informado", 30),
      pagamentos: Array.isArray(pedido.pagamentos)
        ? pedido.pagamentos.slice(0, 2).map(item => ({
            formaPagamento: text(item.formaPagamento, 30),
            valorCentavos: Math.max(0, Math.trunc(number(item.valorCentavos))),
          }))
        : [],
      pagamentoInformadoEm: pedido.pagamentoInformadoEm
        ? new Date(pedido.pagamentoInformadoEm).toISOString()
        : "",
      pagoEm: pedido.pagoEm ? new Date(pedido.pagoEm).toISOString() : "",
      precisaTroco: Boolean(pedido.precisaTroco),
      trocoPara: pedido.trocoPara == null ? null : number(pedido.trocoPara),
      valorTroco: pedido.valorTroco == null ? null : number(pedido.valorTroco),
      createdAt: new Date(pedido.createdAt || Date.now()).toISOString(),
      itens: (pedido.itens || []).slice(0, 100).map(item => ({
        nome: text(item.nome || "Produto", 160),
        quantidade: Math.max(1, Math.min(99, Number(item.quantidade) || 1)),
        preco: number(item.preco),
        subtotal: number(item.subtotal),
        observacao: text(item.observacao, 500),
        pizzaMeioAMeio: item.pizzaMeioAMeio === true,
        regraPrecoPizza: text(item.regraPrecoPizza, 40),
        precoBasePizza: item.precoBasePizza == null
          ? null
          : number(item.precoBasePizza),
        tamanhoPizzaId: text(item.tamanhoPizzaId, 80),
        tamanhoPizzaNome: text(item.tamanhoPizzaNome, 50),
        saboresPizza: (item.saboresPizza || []).slice(0, 3).map(sabor => ({
          produtoId: text(sabor.produtoId, 80),
          nome: text(sabor.nome || "Sabor", 160),
          preco: number(sabor.preco),
          fracao: number(sabor.fracao),
        })),
        adicionais: (item.adicionais || []).slice(0, 30).map(adicional => ({
          nome: text(adicional.nome || "Adicional", 120),
          preco: number(adicional.preco),
        })),
      })),
    },
  };
}

async function contextoDoPedido(pedido, options = {}) {
  const [configuracao, dono] = await Promise.all([
    options.configuracao || Configuracao.findOne({
      estabelecimentoId: pedido.estabelecimentoId,
    }).lean(),
    options.dono || registroModel.findById(pedido.estabelecimentoId)
      .select("cpfCnpj").lean(),
  ]);
  return { configuracao, dono };
}

async function criarJobsAutomaticos(pedido, options = {}) {
  assertAcceptingWork();
  await validarPedidoDisponivel(pedido, { session: options.session });
  if (!isOrderEligibleForAutomaticPrint(pedido)) return [];
  const { configuracao, dono } = await contextoDoPedido(pedido, options);
  const impressoras = (configuracao?.impressoras || []).filter(item =>
    ["automatica", "manual_automatica"].includes(item.modo)
    && impressoraAceitaPedido(item, pedido));
  const jobs = [];
  for (const impressora of impressoras) {
    const snapshot = await montarSnapshotValidado({
      pedido,
      configuracao,
      dono,
      impressora,
    });
    try {
      const [job] = await PrintJob.create([{
        jobId: crypto.randomUUID(),
        estabelecimentoId: pedido.estabelecimentoId,
        pedidoId: pedido._id,
        tipo: "automatica",
        motivo: motivoImpressaoAutomatica(pedido),
        paymentIdSuffix: isPixOnlineOrder(pedido)
          ? String(pedido.mercadoPagoPaymentId || "").slice(-8)
          : "",
        impressoraChave: calcularImpressoraChave(impressora),
        ...snapshot,
        status: "pendente",
        nextAttemptAt: new Date(),
      }], options.session ? { session: options.session } : undefined);
      jobs.push(job);
    } catch (error) {
      if (error?.code !== 11000) throw error;
    }
  }
  // Marca no Pedido que este evento de impressão automática já foi tratado.
  // Esse registro é independente de PrintJob: apagar um job não autoriza o
  // reconciliador a imprimir novamente um pedido antigo.
  await marcarImpressaoAutomaticaProcessada(pedido, { session: options.session || null });
  notifyStore(pedido.estabelecimentoId);
  return jobs;
}

async function criarJobManual({
  pedido,
  impressora,
  configuracao,
  dono,
  session = null,
}) {
  assertAcceptingWork();
  await validarPedidoDisponivel(pedido, { session });
  const context = await contextoDoPedido(pedido, { configuracao, dono });
  const snapshot = await montarSnapshotValidado({
    pedido,
    configuracao: context.configuracao,
    dono: context.dono,
    impressora,
  });
  const documento = {
    jobId: crypto.randomUUID(),
    estabelecimentoId: pedido.estabelecimentoId,
    pedidoId: pedido._id,
    tipo: "manual",
    motivo: "manual",
    impressoraChave: calcularImpressoraChave(impressora),
    ...snapshot,
    status: "pendente",
    nextAttemptAt: new Date(),
  };
  const job = session
    ? (await PrintJob.create([documento], { session }))[0]
    : await PrintJob.create(documento);
  notifyStore(pedido.estabelecimentoId);
  return job;
}

async function criarJobPixMesa({
  attempt,
  mesa,
  pedidos,
  configuracao = null,
  dono = null,
}) {
  assertAcceptingWork();
  if (!attempt?._id || !mesa?._id || !Array.isArray(pedidos) || !pedidos.length) {
    const error = new Error("Dados insuficientes para imprimir o Pix da mesa.");
    error.code = "MESA_PIX_PRINT_DATA_INVALID";
    throw error;
  }
  if (!isPrintProtocolV2EnabledFor(attempt.estabelecimentoId)) {
    const error = new Error("O protocolo de impressão atual não está habilitado para este estabelecimento.");
    error.code = "PRINT_PROTOCOL_NOT_ENABLED";
    throw error;
  }
  const agent = await PrintAgent.findOne({ estabelecimentoId: attempt.estabelecimentoId })
    .select("agentVersion protocolVersion protocolCompativel ativo")
    .lean();
  const versionComparison = compareVersions(agent?.agentVersion, "1.4.0");
  if (!agent?.ativo || !agent?.protocolCompativel || Number(agent?.protocolVersion) !== PROTOCOL_VERSION
    || versionComparison === null || versionComparison < 0) {
    const error = new Error("Atualize o agente de impressão para a versão 1.4.0 ou superior antes de imprimir o QR Code Pix da mesa.");
    error.code = "MESA_PIX_AGENT_UPDATE_REQUIRED";
    error.httpStatus = 409;
    throw error;
  }

  const pedidoBase = pedidos[0];
  const context = await contextoDoPedido(pedidoBase, { configuracao, dono });
  const impressora = (context.configuracao?.impressoras || []).find(item =>
    ["manual", "manual_automatica"].includes(String(item?.modo || ""))
    && impressoraAceitaPedido(item, { canal: "mesa" }));
  if (!impressora) {
    const error = new Error("Configure uma impressora de Mesa no modo Manual ou Manual + Automática para imprimir o QR Code Pix.");
    error.code = "MESA_PIX_PRINTER_NOT_CONFIGURED";
    error.httpStatus = 409;
    throw error;
  }

  const existing = await PrintJob.findOne({
    mesaPaymentAttemptId: attempt._id,
    status: { $nin: ["cancelado"] },
  }).sort({ createdAt: -1 });
  if (existing) return existing;

  const snapshot = await montarSnapshotValidado({
    pedido: pedidoBase,
    configuracao: context.configuracao,
    dono: context.dono,
    impressora,
  });
  const totalCentavos = Math.max(0, Math.round(Number(attempt.expectedAmount || 0) * 100));
  snapshot.pedido = {
    ...snapshot.pedido,
    id: `mesa-pix:${String(attempt.attemptId)}`,
    numero: `MESA-${String(mesa.numero || "")}`,
    origem: `Mesa ${String(mesa.numero || "")}`.trim(),
    canal: "mesa",
    mesaNumero: Number(mesa.numero || 0) || null,
    cliente: `Mesa ${String(mesa.numero || "")}`.trim(),
    observacao: "Pagamento Pix da conta da mesa.",
    subtotalProdutos: Number(attempt.expectedAmount || 0),
    taxaEntregaCentavos: 0,
    taxaEntrega: 0,
    total: Number(attempt.expectedAmount || 0),
    status: "novo",
    pagamentoStatus: "pendente",
    formaPagamento: "pix_online",
    pagamentos: [{ formaPagamento: "pix_online", valorCentavos: totalCentavos }],
    pagamentoInformadoEm: new Date().toISOString(),
    pagoEm: "",
    precisaTroco: false,
    trocoPara: null,
    valorTroco: null,
    createdAt: new Date(attempt.createdAt || Date.now()).toISOString(),
    itens: [{
      nome: "Pagamento Pix da mesa",
      quantidade: 1,
      preco: Number(attempt.expectedAmount || 0),
      subtotal: Number(attempt.expectedAmount || 0),
      observacao: "",
      pizzaMeioAMeio: false,
      regraPrecoPizza: "",
      precoBasePizza: null,
      tamanhoPizzaId: "",
      tamanhoPizzaNome: "",
      saboresPizza: [],
      adicionais: [],
    }],
    pixPagamento: {
      copiaCola: text(attempt.pixCopiaCola, 5_000),
      expiraEm: new Date(attempt.expiresAt).toISOString(),
      valor: Number(attempt.expectedAmount || 0),
      mesaNumero: Number(mesa.numero || 0),
    },
  };

  const job = await PrintJob.create({
    jobId: crypto.randomUUID(),
    estabelecimentoId: attempt.estabelecimentoId,
    pedidoId: pedidoBase._id,
    mesaPaymentAttemptId: attempt._id,
    tipo: "manual",
    motivo: "pix_mesa",
    paymentIdSuffix: String(attempt.paymentId || "").slice(-8),
    impressoraChave: calcularImpressoraChave(impressora),
    ...snapshot,
    status: "pendente",
    nextAttemptAt: new Date(),
  });
  notifyStore(attempt.estabelecimentoId);
  return job;
}

async function anexarResultadoPublico(pedido, token, { replay = false } = {}) {
  Object.defineProperty(pedido, "acompanhamentoToken", {
    value: token,
    enumerable: false,
  });
  Object.defineProperty(pedido, "idempotentReplay", {
    value: Boolean(replay),
    enumerable: false,
  });
  return pedido;
}

async function buscarPedidoIdempotente(dados, token, payloadHash) {
  if (!dados.idempotencyKey) return null;
  const pedido = await Pedido.findOne({
    estabelecimentoId: dados.estabelecimentoId,
    canal: dados.canal,
    idempotencyKey: dados.idempotencyKey,
  });
  if (!pedido) return null;
  if (
    pedido.idempotencyPayloadHash
    && payloadHash
    && pedido.idempotencyPayloadHash !== payloadHash
  ) {
    throw createIdempotencyConflictError();
  }
  return anexarResultadoPublico(pedido, token, { replay: true });
}

function notificarPedidoCriadoNoPainel(pedido) {
  if (!pedido) return;
  adminRealtimeService.publish(pedido.estabelecimentoId, {
    reason: "pedido_criado",
    pedidoId: String(pedido._id || ""),
    mesaId: String(pedido.mesaId || ""),
  });
}

async function criarPedidoComJobsAutomaticos(
  dados,
  tentativaCodigo = 0,
  numeroReservado = null,
) {
  assertAcceptingWork();
  const payloadHash = dados.idempotencyKey ? hashPublicOrderPayload(dados) : "";
  const tokenAcompanhamento = dados.idempotencyKey
    ? gerarTokenAcompanhamentoIdempotente({
        estabelecimentoId: dados.estabelecimentoId,
        canal: dados.canal,
        idempotencyKey: dados.idempotencyKey,
      })
    : gerarTokenAcompanhamento();

  const existente = await buscarPedidoIdempotente(dados, tokenAcompanhamento.token, payloadHash);
  if (existente) return existente;

  const sequencia = numeroReservado || await reservarNumeroPedido({
    estabelecimentoId: dados.estabelecimentoId,
  });
  const codigoPublico = gerarCodigoPublico();
  const dadosComToken = {
    ...dados,
    numeroPedido: sequencia.numeroPedido,
    numeroPedidoData: sequencia.numeroPedidoData,
    codigoPublico,
    codigoPublicoFinal: codigoFinal(codigoPublico),
    acompanhamentoTokenHash: tokenAcompanhamento.hash,
    acompanhamentoTokenCriadoEm: tokenAcompanhamento.criadoEm,
    acompanhamentoTokenExpiraEm: tokenAcompanhamento.expiraEm,
    idempotencyPayloadHash: payloadHash,
  };
  const session = await Pedido.startSession();
  try {
    let pedido;
    await session.withTransaction(async () => {
      [pedido] = await Pedido.create([dadosComToken], { session });
      await criarJobsAutomaticos(pedido, { session });
    });
    notificarPedidoCriadoNoPainel(pedido);
    return anexarResultadoPublico(pedido, tokenAcompanhamento.token);
  } catch (error) {
    const colisaoIdempotencia = Number(error?.code) === 11000
      && (error?.keyPattern?.idempotencyKey
        || String(error?.message || "").includes("pedido_criacao_idempotente_unica"));
    if (colisaoIdempotencia) {
      const repetido = await buscarPedidoIdempotente(dados, tokenAcompanhamento.token, payloadHash);
      if (repetido) return repetido;
    }

    const colisaoCodigo = Number(error?.code) === 11000
      && (error?.keyPattern?.codigoPublico
        || String(error?.message || "").includes("pedido_codigo_publico_tenant_unico"));
    if (colisaoCodigo && tentativaCodigo < 5) {
      return criarPedidoComJobsAutomaticos(dados, tentativaCodigo + 1, sequencia);
    }
    const unsupported = /Transaction numbers|replica set|transactions are not supported/i
      .test(String(error?.message || ""));
    if (!unsupported) throw error;
    appLogger.warn("MongoDB sem transações; usando criação idempotente com reconciliador.");
    let pedido;
    try {
      pedido = await Pedido.create(dadosComToken);
    } catch (fallbackError) {
      const colisaoIdempotenciaFallback = Number(fallbackError?.code) === 11000
        && (fallbackError?.keyPattern?.idempotencyKey
          || String(fallbackError?.message || "").includes("pedido_criacao_idempotente_unica"));
      if (colisaoIdempotenciaFallback) {
        const repetido = await buscarPedidoIdempotente(dados, tokenAcompanhamento.token, payloadHash);
        if (repetido) return repetido;
      }
      const colisaoFallback = Number(fallbackError?.code) === 11000
        && (fallbackError?.keyPattern?.codigoPublico
          || String(fallbackError?.message || "").includes("pedido_codigo_publico_tenant_unico"));
      if (colisaoFallback && tentativaCodigo < 5) {
        return criarPedidoComJobsAutomaticos(dados, tentativaCodigo + 1, sequencia);
      }
      throw fallbackError;
    }
    await criarJobsAutomaticos(pedido);
    notificarPedidoCriadoNoPainel(pedido);
    return anexarResultadoPublico(pedido, tokenAcompanhamento.token);
  } finally {
    await session.endSession();
  }
}

async function reivindicarProximoJob(estabelecimentoId) {
  if (shuttingDown) return null;
  const now = new Date();
  const leaseToken = crypto.randomUUID();
  return PrintJob.findOneAndUpdate({
    estabelecimentoId,
    status: { $in: ["pendente", "aguardando_retry"] },
    // Impressões manuais só podem ser reenviadas por uma ação explícita do usuário.
    // Jobs manuais antigos que tenham ficado em aguardando_retry não voltam a sair sozinhos.
    $nor: [{ tipo: "manual", status: "aguardando_retry" }],
    tentativas: { $lt: MAX_ATTEMPTS },
    $and: [
      {
        $or: [
          { nextAttemptAt: null },
          { nextAttemptAt: { $lte: now } },
        ],
      },
      {
        $or: [
          { leaseExpiresAt: null },
          { leaseExpiresAt: { $lt: now } },
        ],
      },
    ],
  }, {
    $set: {
      lockedBy: INSTANCE_ID,
      leaseToken,
      ultimoLeaseId: leaseToken,
      leaseExpiresAt: new Date(now.getTime() + LEASE_MS),
      lastAttemptAt: now,
      status: "pendente",
    },
    $inc: { tentativas: 1 },
  }, {
    sort: { createdAt: 1 },
    returnDocument: "after",
  });
}

function leaseFilter(job) {
  return {
    _id: job._id,
    lockedBy: INSTANCE_ID,
    leaseToken: job.leaseToken,
  };
}

async function programarRetry(job, error, { permanente = false } = {}) {
  const attempts = Number(job.tentativas || 0);
  const filter = job.lockedBy === INSTANCE_ID && job.leaseToken
    ? leaseFilter(job)
    : {
        _id: job._id,
        status: {
          $in: ["recebido", "processando", "resultado_desconhecido", "falhou"],
        },
      };

  // Uma impressão solicitada manualmente nunca entra em retry automático.
  // Isso evita vias duplicadas quando a impressora já recebeu o RAW, mas o
  // Windows/agente reporta uma falha tardia. O usuário pode usar Reimprimir.
  if (String(job.tipo || "") === "manual") {
    return PrintJob.findOneAndUpdate(filter, {
      $set: {
        status: "falhou",
        erro: text(
          `Impressão manual não reenviada automaticamente. Use Reimprimir se necessário. ${error?.message || error || ""}`,
          1000,
        ),
        nextAttemptAt: null,
        lockedBy: "",
        leaseToken: "",
        leaseExpiresAt: null,
      },
    }, { returnDocument: "after" });
  }

  if (permanente || attempts >= MAX_ATTEMPTS) {
    return PrintJob.findOneAndUpdate(filter, {
      $set: {
        status: "falhou",
        erro: text(error?.message || error, 1000),
        lockedBy: "",
        leaseToken: "",
        leaseExpiresAt: null,
      },
    }, { returnDocument: "after" });
  }
  const base = RETRY_DELAYS[Math.min(attempts, RETRY_DELAYS.length - 1)];
  const jitter = Math.floor(base * (Math.random() * 0.2));
  return PrintJob.findOneAndUpdate(filter, {
    $set: {
      status: "aguardando_retry",
      erro: text(error?.message || error, 1000),
      nextAttemptAt: new Date(Date.now() + base + jitter),
      lockedBy: "",
      leaseToken: "",
      leaseExpiresAt: null,
    },
  }, { returnDocument: "after" });
}

async function atualizarStatusDoAgente(estabelecimentoId, status = {}) {
  let validated;
  try {
    validated = validateAgentStatus(status);
  } catch {
    return null;
  }
  const job = await PrintJob.findOne({
    jobId: validated.jobId,
    estabelecimentoId,
  });
  if (!job || ["concluido", "cancelado"].includes(job.status)) return job;
  if (
    job.lockedBy !== INSTANCE_ID
    || !job.leaseToken
    || job.leaseToken !== validated.leaseId
    || calcularImpressoraId(job.impressora) !== validated.impressoraId
  ) {
    appLogger.warn(
      `ACK de impressão ignorado: jobId=${validated.jobId} lease=${validated.leaseId.slice(0, 8)} code=LEASE_OR_PRINTER_MISMATCH`,
    );
    return null;
  }
  const now = new Date();
  const update = { erro: text(validated.message, 1000) };
  if (["recebido", "validado", "aceito"].includes(validated.status)) {
    update.status = "recebido";
    if (!job.recebidoEm) update.recebidoEm = now;
  } else if (validated.status === "imprimindo") {
    update.status = "processando";
    if (!job.processandoEm) update.processandoEm = now;
    update.leaseExpiresAt = new Date(now.getTime() + LEASE_MS);
  } else if (validated.status === "enviado_impressora") {
    update.status = "enviado";
    if (!job.enviadoEm) update.enviadoEm = now;
    update.leaseExpiresAt = new Date(now.getTime() + LEASE_MS);
  } else if (validated.status === "concluido") {
    update.status = "concluido";
    if (!job.enviadoEm) update.enviadoEm = now;
    update.concluidoEm = now;
    update.lockedBy = "";
    update.leaseToken = "";
    update.leaseExpiresAt = null;
  } else if (validated.status === "falhou_antes_envio") {
    // O agente já recebeu o job e respondeu sobre ele. Depois desse ponto não
    // existe retry automático: alguns drivers podem sinalizar erro após
    // aceitarem os bytes, o que poderia gerar uma segunda via.
    update.status = "falhou";
    update.erro = text(
      `Agente recebeu o job, mas informou falha antes do envio. Retry automático bloqueado para evitar duplicidade. ${validated.message || ""}`,
      1000,
    );
    update.nextAttemptAt = null;
    update.lockedBy = "";
    update.leaseToken = "";
    update.leaseExpiresAt = null;
  } else if (validated.status === "resultado_desconhecido") {
    update.status = "resultado_desconhecido";
    update.leaseExpiresAt = new Date(now.getTime() + LEASE_MS);
  } else {
    return job;
  }
  return PrintJob.findOneAndUpdate(leaseFilter(job), { $set: update }, {
    returnDocument: "after",
  });
}

async function consultarResultadoDesconhecido(job, socket) {
  if (!transport || !socket) return job;
  const deliveryLeaseId = String(job.ultimoLeaseId || job.leaseToken || "");
  if (!UUID_PATTERN.test(deliveryLeaseId)) return job;
  let result;
  try {
    result = await transport.query(socket, job.jobId, deliveryLeaseId);
  } catch {
    return job;
  }
  if (result?.status === "nao_encontrado") {
    const manual = String(job.tipo || "") === "manual";
    const safeJob = await PrintJob.findOneAndUpdate({
      _id: job._id,
      status: "resultado_desconhecido",
      ultimoLeaseId: deliveryLeaseId,
    }, {
      $set: {
        status: manual ? "falhou" : "aguardando_retry",
        erro: manual
          ? "O agente confirmou que não recebeu a impressão manual. Use Reimprimir se necessário."
          : "O agente confirmou que não recebeu o trabalho.",
        nextAttemptAt: manual ? null : new Date(),
        lockedBy: "",
        leaseToken: "",
        leaseExpiresAt: null,
      },
    }, { returnDocument: "after" });
    if (safeJob && !manual) notifyStore(safeJob.estabelecimentoId);
    return safeJob || job;
  }
  try {
    result = validateAgentStatus(result);
    if (result.jobId !== job.jobId || result.leaseId !== deliveryLeaseId) {
      result = null;
    }
  } catch {
    result = null;
  }
  if (result?.status === "concluido") {
    return PrintJob.findOneAndUpdate({
      _id: job._id,
      status: { $nin: ["concluido", "cancelado"] },
      ultimoLeaseId: deliveryLeaseId,
    }, {
      $set: {
        status: "concluido",
        erro: "",
        enviadoEm: job.enviadoEm || new Date(),
        concluidoEm: new Date(),
        lockedBy: "",
        leaseToken: "",
        leaseExpiresAt: null,
      },
    }, { returnDocument: "after" });
  }
  if (["imprimindo", "recebido", "validado", "aceito", "enviado_impressora"]
    .includes(result?.status)) {
    const serverStatus = result.status === "imprimindo"
      ? "processando"
      : (result.status === "enviado_impressora" ? "enviado" : "recebido");
    return PrintJob.findOneAndUpdate({
      _id: job._id,
      status: { $nin: ["concluido", "cancelado"] },
      ultimoLeaseId: deliveryLeaseId,
    }, {
      $set: {
        status: serverStatus,
        leaseExpiresAt: new Date(Date.now() + LEASE_MS),
      },
    }, { returnDocument: "after" });
  }
  if (result?.status === "falhou_antes_envio") {
    const failed = await PrintJob.findOneAndUpdate({
      _id: job._id,
      status: { $nin: ["concluido", "cancelado"] },
      ultimoLeaseId: deliveryLeaseId,
    }, {
      $set: {
        status: "falhou",
        erro: text(
          `Agente confirmou falha após receber o job. Retry automático bloqueado para evitar duplicidade. ${result.message || ""}`,
          1000,
        ),
        nextAttemptAt: null,
        lockedBy: "",
        leaseToken: "",
        leaseExpiresAt: null,
      },
    }, { returnDocument: "after" });
    return failed || job;
  }
  // Ausência local, protocolo antigo ou resultado ambíguo nunca liberam retry.
  return PrintJob.findOneAndUpdate({
    _id: job._id,
    status: { $nin: ["concluido", "cancelado"] },
    ultimoLeaseId: deliveryLeaseId,
  }, {
    $set: {
      status: "resultado_desconhecido",
      erro: "Resultado exige conciliação manual.",
      leaseExpiresAt: new Date(Date.now() + LEASE_MS),
    },
  }, { returnDocument: "after" });
}

async function reconciliarResumoDoAgente(estabelecimentoId, summary = {}) {
  if (
    Number(summary.protocolVersion) !== PROTOCOL_VERSION
    || !Array.isArray(summary.jobs)
    || summary.jobs.length > 100
  ) {
    throw new Error("Resumo de reconciliação inválido.");
  }
  const decisions = [];
  for (const local of summary.jobs) {
    if (
      !UUID_PATTERN.test(String(local?.jobId || ""))
      || !UUID_PATTERN.test(String(local?.leaseId || ""))
      || !AGENT_STATUSES.has(String(local?.status || ""))
    ) continue;
    const job = await PrintJob.findOne({
      jobId: String(local.jobId),
      estabelecimentoId,
    });
    if (!job || job.status === "cancelado") {
      decisions.push({
        jobId: String(local.jobId),
        leaseId: String(local.leaseId),
        action: "cancelar",
      });
      continue;
    }
    if (calcularImpressoraId(job.impressora) !== String(local.impressoraId || "")) {
      decisions.push({
        jobId: job.jobId,
        leaseId: String(local.leaseId),
        action: "aguardar",
      });
      continue;
    }
    if (job.status === "concluido") {
      decisions.push({
        jobId: job.jobId,
        leaseId: String(local.leaseId),
        action: "concluido",
      });
      continue;
    }
    if (
      local.status === "falhou_antes_envio"
      && String(job.leaseToken) === String(local.leaseId)
    ) {
      // Se o job aparece no resumo local do agente, ele já foi recebido.
      // Portanto, nunca liberamos uma nova impressão automaticamente.
      await PrintJob.findOneAndUpdate({
        _id: job._id,
        estabelecimentoId,
        leaseToken: String(local.leaseId),
        status: {
          $in: ["entregando", "recebido", "processando", "enviado", "resultado_desconhecido"],
        },
      }, {
        $set: {
          status: "falhou",
          erro: "O agente recebeu o job e informou falha. Retry automático bloqueado para evitar impressão duplicada. Use Reimprimir se necessário.",
          nextAttemptAt: null,
          lockedBy: "",
          leaseToken: "",
          leaseExpiresAt: null,
        },
      });
      decisions.push({
        jobId: job.jobId,
        leaseId: String(local.leaseId),
        action: "aguardar",
      });
      continue;
    }
    decisions.push({
      jobId: job.jobId,
      leaseId: String(local.leaseId),
      action: local.status === "resultado_desconhecido"
        ? "manter_desconhecido"
        : "aguardar",
    });
  }
  return decisions;
}

async function prepararEntrega(job) {
  const pedidoAtivo = await Pedido.exists({
    _id: job.pedidoId,
    estabelecimentoId: job.estabelecimentoId,
    excluido: { $ne: true },
  });
  if (!pedidoAtivo) {
    await PrintJob.findOneAndUpdate(leaseFilter(job), {
      $set: {
        status: "cancelado",
        erro: "Pedido arquivado; impressão cancelada.",
        lockedBy: "",
        leaseToken: "",
        leaseExpiresAt: null,
      },
    });
    return null;
  }
  return PrintJob.findOneAndUpdate(
    {
      ...leaseFilter(job),
      status: "pendente",
      leaseExpiresAt: { $gt: new Date() },
    },
    {
      $set: {
        status: "entregando",
        erro: "",
        leaseExpiresAt: new Date(Date.now() + LEASE_MS),
      },
    },
    { returnDocument: "after" },
  );
}

async function processarJob(job, socket) {
  if (!isPrintProtocolV2EnabledFor(job.estabelecimentoId)) return null;
  const entregando = await prepararEntrega(job);
  if (!entregando) return null;
  try {
    const initial = await transport.deliver(socket, buildJobEnvelope({
      jobId: entregando.jobId,
      leaseId: entregando.leaseToken,
      impressoraId: calcularImpressoraId(entregando.impressora),
      attempt: entregando.tentativas,
      deadline: new Date(Date.now() + LEASE_MS).toISOString(),
      modo: entregando.tipo,
      estabelecimento: entregando.estabelecimento,
      pedido: sanitizarPedidoParaAgente(entregando.pedido),
      impressoras: [entregando.impressora],
    }));
    await atualizarStatusDoAgente(entregando.estabelecimentoId, {
      jobId: entregando.jobId,
      leaseId: entregando.leaseToken,
      protocolVersion: PROTOCOL_VERSION,
      agentVersion: initial.agentVersion,
      impressoraId: calcularImpressoraId(entregando.impressora),
      timestamp: initial.timestamp || new Date().toISOString(),
      status: initial.status || "recebido",
      ...initial,
    });
  } catch (error) {
    await PrintJob.findOneAndUpdate(leaseFilter(entregando), {
      $set: {
        status: "resultado_desconhecido",
        erro: text(error.message, 1000),
        leaseExpiresAt: new Date(Date.now() + LEASE_MS),
      },
    });
    const current = await PrintJob.findOne(leaseFilter(entregando));
    if (!current) return null;
    await consultarResultadoDesconhecido(current, socket);
  }
  return entregando;
}

async function drenarFilaDoEstabelecimento(estabelecimentoId, socket) {
  if (shuttingDown) return;
  if (!isPrintProtocolV2EnabledFor(estabelecimentoId)) return;
  const key = String(estabelecimentoId);
  if (activeStores.has(key) || !socket?.connected || !transport) return;
  activeStores.add(key);
  try {
    const unknown = await PrintJob.find({
      estabelecimentoId,
      status: "resultado_desconhecido",
    }).sort({ createdAt: 1 }).limit(20);
    for (const job of unknown) {
      if (!socket.connected) return;
      await consultarResultadoDesconhecido(job, socket);
    }
    while (socket.connected) {
      const job = await reivindicarProximoJob(estabelecimentoId);
      if (!job) break;
      await processarJob(job, socket);
      const current = await PrintJob.findById(job._id).select("status").lean();
      if (current?.status === "recebido" || current?.status === "processando") break;
    }
  } finally {
    activeStores.delete(key);
  }
}

async function recuperarLeasesExpirados() {
  if (shuttingDown) return;
  const now = new Date();
  await finalizarJobsEsgotados({ now });

  // Neutraliza retries manuais deixados por versões anteriores antes que o
  // agente possa reivindicá-los novamente após um deploy/reinício.
  await PrintJob.updateMany({
    tipo: "manual",
    status: "aguardando_retry",
  }, {
    $set: {
      status: "falhou",
      erro: "Retry automático de impressão manual desativado. Use Reimprimir se necessário.",
      nextAttemptAt: null,
      lockedBy: "",
      leaseToken: "",
      leaseExpiresAt: null,
    },
  });

  // Neutraliza retries automáticos criados por versões anteriores quando já
  // há evidência de que o agente recebeu/processou o job. Esses trabalhos não
  // podem voltar para a impressora sozinhos após o deploy.
  await PrintJob.updateMany({
    tipo: "automatica",
    status: "aguardando_retry",
    $or: [
      { recebidoEm: { $ne: null } },
      { processandoEm: { $ne: null } },
      { enviadoEm: { $ne: null } },
      { erro: "Falha antes do envio confirmada pelo agente." },
    ],
  }, {
    $set: {
      status: "falhou",
      erro: "Retry automático bloqueado: o agente já havia recebido ou processado este job. Use Reimprimir se necessário.",
      nextAttemptAt: null,
      lockedBy: "",
      leaseToken: "",
      leaseExpiresAt: null,
    },
  });

  await PrintJob.updateMany({
    status: {
      $in: ["entregando", "recebido", "processando", "enviado", "resultado_desconhecido"],
    },
    leaseExpiresAt: { $lt: now },
  }, {
    $set: {
      status: "resultado_desconhecido",
      lockedBy: "",
      leaseToken: "",
    },
  });
}

async function reconciliarPedidosSemJob({
  since = new Date(Date.now() - ORDER_PRINT_RECONCILIATION_WINDOW_MS),
} = {}) {
  if (shuttingDown) return;

  const limite = since instanceof Date && Number.isFinite(since.getTime())
    ? since
    : new Date(Date.now() - ORDER_PRINT_RECONCILIATION_WINDOW_MS);

  // Recupera somente pedidos recentes cujo evento de impressão automática ainda
  // não foi marcado como processado. Isso cobre uma queda entre salvar o pedido
  // e criar o job, sem transformar o reconciliador em uma reimpressão histórica.
  const pedidos = await Pedido.find({
    createdAt: { $gte: limite },
    excluido: { $ne: true },
    $or: [
      { impressaoAutomaticaProcessadaEm: null },
      { impressaoAutomaticaProcessadaEm: { $exists: false } },
    ],
  }).sort({ createdAt: 1 }).limit(500);

  for (const pedido of pedidos) {
    if (!isOrderEligibleForAutomaticPrint(pedido)) continue;
    if (impressaoAutomaticaJaProcessada(pedido)) continue;
    await criarJobsAutomaticos(pedido);
  }
}

function notifyStore(estabelecimentoId) {
  if (!shuttingDown && transport) transport.wake(String(estabelecimentoId));
}

async function retryJob(job) {
  assertAcceptingWork();
  if (!["falhou", "resultado_desconhecido"].includes(job.status)) {
    throw new Error("Este trabalho não pode ser reenviado.");
  }
  if (job.status === "resultado_desconhecido") {
    throw new Error("O resultado desconhecido precisa ser reconciliado com o agente.");
  }
  const pedidoAtivo = await Pedido.exists({
    _id: job.pedidoId,
    estabelecimentoId: job.estabelecimentoId,
    excluido: { $ne: true },
  });
  if (!pedidoAtivo) {
    throw new Error("Pedido arquivado não pode ser reenviado para impressão.");
  }
  job.status = "pendente";
  job.nextAttemptAt = new Date();
  job.erro = "";
  job.lockedBy = "";
  job.leaseToken = "";
  job.leaseExpiresAt = null;
  job.tentativas = 0;
  await job.save();
  notifyStore(job.estabelecimentoId);
  return job;
}

async function reconciliarJobManual(job, action) {
  assertAcceptingWork();
  if (job.status !== "resultado_desconhecido") {
    throw new Error("Somente resultado desconhecido pode ser conciliado.");
  }
  if (!["confirmar_concluido", "liberar_retry"].includes(action)) {
    throw new Error("Ação de conciliação inválida.");
  }
  const now = new Date();
  const update = action === "confirmar_concluido"
    ? {
        status: "concluido",
        erro: "Concluído por conciliação manual.",
        enviadoEm: job.enviadoEm || now,
        concluidoEm: now,
        lockedBy: "",
        leaseToken: "",
        leaseExpiresAt: null,
      }
    : {
        // Esta é uma ação humana explícita, portanto pode voltar a pendente.
        // O que fica proibido é o retry automático de jobs do tipo manual.
        status: "pendente",
        erro: "Reenvio liberado por conciliação manual.",
        nextAttemptAt: now,
        lockedBy: "",
        leaseToken: "",
        leaseExpiresAt: null,
      };
  const result = await PrintJob.findOneAndUpdate({
    _id: job._id,
    estabelecimentoId: job.estabelecimentoId,
    status: "resultado_desconhecido",
  }, { $set: update }, { returnDocument: "after" });
  if (!result) throw new Error("O estado do trabalho mudou. Atualize e tente novamente.");
  if (action === "liberar_retry") notifyStore(job.estabelecimentoId);
  return result;
}

module.exports = {
  INSTANCE_ID,
  MAX_ATTEMPTS,
  calcularImpressoraChave,
  calcularImpressoraId,
  impressoraAceitaPedido,
  impressoraPodeAtenderJob,
  normalizarOrigemPedidosImpressora,
  criarJobManual,
  criarJobPixMesa,
  criarJobsAutomaticos,
  criarPedidoComJobsAutomaticos,
  isOrderEligibleForAutomaticPrint,
  isPixOnlineOrder,
  drenarFilaDoEstabelecimento,
  montarSnapshotValidado,
  prepararEntrega,
  processarJob,
  programarRetry,
  recuperarLeasesExpirados,
  finalizarJobsEsgotados,
  reconciliarJobsComImpressorasAtuais,
  reconciliarJobsOrfaos,
  reconciliarPedidosSemJob,
  reivindicarProximoJob,
  retryJob,
  reconciliarJobManual,
  setShuttingDown,
  setTransport,
  validarPedidoDisponivel,
  atualizarStatusDoAgente,
  consultarResultadoDesconhecido,
  reconciliarResumoDoAgente,
  sanitizarImpressora,
  sanitizarPedidoParaAgente,
};
